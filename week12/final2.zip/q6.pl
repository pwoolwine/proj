#!/bin/perl -w
#takes a protein sequence accession number as input (on the command line), then fetches this sequence from GenBank, 
#BLASTs it against the non-redundant database, and then retrieves all the hits that are above a certain e-value cutoff 
#(also given as input on the command line). The retrieved sequences are written to files, one sequence per file, in the 
#current directory. If no hits satisfy the e-value cutoff, the script notes that instead of writing any files (e.g. ALM10498.1 1e-100).
#adapted from http://search.cpan.org/dist/BioPerl/Bio/Tools/Run/RemoteBlast.pm

use strict;
use warnings;
use Bio::Perl;
use Bio::Seq;
use Bio::SeqIO;
use Bio::SeqIO::genbank;
use Bio::DB::GenBank;
use Bio::Tools::Run::RemoteBlast;

my $inblastformat = 'blastp';
my $db = 'nr';
#my $e_val='1e-10';

my $usage = "q6.pl inaccession ineval\n";
	    
	  my $acc = shift or die $usage;
	  my $e_val = shift or die $usage;
	  
my $gb_dbh = Bio::DB::GenBank->new( -format => 'fasta' );

my $rb_dbh = Bio::Tools::Run::RemoteBlast->new(-prog => $inblastformat, -db => $db, -expect => $e_val);

my $seq_obj = $gb_dbh->get_Seq_by_acc( $acc );

my $report_obj = $rb_dbh->submit_blast( $seq_obj );

my $v = 1;
my @hits;
my $hitcount;

print STDERR "waiting..." if( $v > 0 );
    while ( my @rids = $rb_dbh->each_rid ) {
      foreach my $rid ( @rids ) {
        my $rc = $rb_dbh->retrieve_blast($rid);
	if( !ref($rc) ) {
          if( $rc < 0 ) {
            $rb_dbh->remove_rid($rid);
          }
          print STDERR "." if ( $v > 0 );
          sleep 5;
        } else {
          
	  my $result = $rc->next_result();
	  $hitcount= $result->num_hits;
	  
	  if( $hitcount == 0 ){ die "No hits! $!" ;}
	  
          #save the output
	  while( my $hit = $result->next_hit() ) {
	  @hits = $hit->name;
          foreach my $item(@hits) {
		my $header = $item;
		
		#parses each section of header
		my @header_split = split /\|/,$header;

		my $hit_acc = $header_split[1];
		$seq_obj = $gb_dbh->get_Seq_by_acc( $hit_acc );
		my $seqio_obj = Bio::SeqIO->new( -file => ">$hit_acc", -format => 'fasta' );
		$seqio_obj->write_seq( $seq_obj );
		}
          $rb_dbh->remove_rid($rid);
	  
          }
        }
      }
    } 
