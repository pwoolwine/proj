#!/bin/perl -w
#creates objects that generates both a fixed length and a random length random protein sequences.

use strict;
use warnings;
use protein;

my $object;

$object = new protein( "test", 50,  );
protein::random_protein($object->{_length}, $object->{_random_length});

$object = new protein( "test", 50, 1 , );
protein::random_protein($object->{_length}, $object->{_random_length});

