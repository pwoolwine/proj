#! /opt/perl/bin/perl
#non-object oriented random_protein function generates a fixed and a random length random protein sequence. 
  
use strict;
use warnings;
  
my @aa = qw/ A N C E H L M P S W R D Q G I K F U T Y V /;
  
sub random_protein {
    my( $length , $random_length ) = @_;
  
    if ( $random_length ) {
      $length = int( rand( $length ));
    }
  
    foreach ( 1 .. $length ) {
      print $aa[int(rand(21))];
    }
    print "\n";
  }
  
random_protein( 50 );
random_protein( 50 , 1 );
