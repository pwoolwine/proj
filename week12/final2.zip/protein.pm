package protein;

sub new
{
	my $class = shift;
	my $protein = {
		_name	 => shift,
		_length  => shift,
		_random_length => shift,
		_sequence => shift,
	};
	return bless $protein, $class;
}

  
  
  
  sub random_protein {
	
    my @aa =  qw/ A N C E H L M P S W R D Q G I K F U T Y V /;

    my( $length, $random_length ) = @_;
  
    if ( $random_length ) {
      $length = int( rand( $length ));
    }
  
    foreach ( 1 .. $length ) {
      print $aa[int(rand(21))];
    }
    print "\n";
  }
  
1;

