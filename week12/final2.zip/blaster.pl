#!/bin/perl -w
#uses RemoteBlast. takes input: blastn dna $accession_number, tblastn protein $accession_number, blastp protein  $accession_number
#detects when the first two arguments don't match
#Output written to a file in the local directory, named for the query sequence and the search algorithm.
#code adapted from http://search.cpan.org/dist/BioPerl/Bio/Tools/Run/RemoteBlast.pm

use strict;
use warnings;
use Bio::Perl;
use Bio::Seq;
use Bio::SeqIO;
use Bio::DB::GenBank;
use Bio::Tools::Run::RemoteBlast;


my $usage = "blaster.pl inblastformat inseqtype inaccession\n";
	  my $inblastformat = shift or die $usage;
          chomp($inblastformat);
	  my $inseqformat = shift or die $usage;
	  chomp($inseqformat);
	  my $acc = shift or die $usage;
  	  chomp($acc);

if( ((($inblastformat eq "blastn") || ($inblastformat eq "blastx") || ($inblastformat eq "tblastx")) && ($inseqformat eq "dna")) || ((($inblastformat eq "blastp") || ($inblastformat eq "tblastn")) && ($inseqformat eq "protein")))
{ 

my $gb_dbh = Bio::DB::GenBank->new( -format => 'fasta' );

my $rb_dbh = Bio::Tools::Run::RemoteBlast->new(-prog => $inblastformat );

my $seq_obj = $gb_dbh->get_Seq_by_acc( $acc );

my $report_obj = $rb_dbh->submit_blast( $seq_obj );

my $v = 1;

print STDERR "waiting..." if( $v > 0 );
    while ( my @rids = $rb_dbh->each_rid ) {
      foreach my $rid ( @rids ) {
        my $rc = $rb_dbh->retrieve_blast($rid);
        if( !ref($rc) ) {
          if( $rc < 0 ) {
            $rb_dbh->remove_rid($rid);
          }
          print STDERR "." if ( $v > 0 );
          sleep 200;
        } else {
          my $result = $rc->next_result();
          #save the output
          my $filename = $result->query_name().$inblastformat."\.out";
          $rb_dbh->save_output($filename);
          $rb_dbh->remove_rid($rid);
          
        }
      }
    }
} else { die "ERROR: not a valid algorithm and sequence combination: $!";}



