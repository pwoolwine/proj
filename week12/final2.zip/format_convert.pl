#!/bin/perl -w
#converts a sequence file (in any format) to any other format that BioPerl supports
#adapted from http://bioperl.org/howtos/SeqIO_HOWTO.html

use strict;
use warnings;
use Bio::SeqIO;


my $usage = "format_convert.pl infile infileformat outfile outfileformat\n";
	  my $infile = shift or die $usage;
	  #my $infileformat = shift or die $usage;
	  #my $outfile = shift or die $usage;
	  my $outfileformat = shift or die $usage;
	  
	  # create one SeqIO object to read in,and another to write out
	  my $seq_in = Bio::SeqIO->new('-file' => "<$infile");
	                               
          my $seq_out = Bio::SeqIO->new('-file' => ">$infile.$outfileformat",
                                        '-format' => $outfileformat);

          # write each entry in the input file to the output file
          while (my $inseq = $seq_in->next_seq) {
             $seq_out->write_seq($inseq);
          }
          exit;
