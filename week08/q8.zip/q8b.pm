package menzyme;
use Moose;

=pod

=head1 NAME

menzyme.pm - moose perl oop for restriction enzyme digestion 

=head1 SYNOPSIS

Basic restriction enzyme class with name, pattern, cut site, manufacturer, and sequence input attributes.
Returns digested dna fragments.
Requires passing a single sequence fasta to the calling program. 

examples:
		perl q8a.pl data.fasta

=head1 AUTHOR

Phillip Woolwine

=head1 DATE

7/25/2016

=cut


has name => (
	is => 'rw',
	isa => 'Str',
);

has pattern => (
	is => 'rw',
	isa => 'Str',
);

has cut => (
	is => 'rw',
	isa => 'Str',
);

has manufacturer => (
	is => 'rw',
	isa => 'Str',
);

has sequence => (
	is => 'rw',
	isa => 'Str',
);

sub cut_dna {
	my ($seq, $pattern, $cut) = @_;
	$seq =~ s/$pattern/$cut/gi;
	my @words = split(/'/i,$seq);
	return \@words;
}
1;
